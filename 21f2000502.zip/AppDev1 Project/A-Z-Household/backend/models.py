from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Customer Table
class Customer(db.Model):
    __tablename__ = "customers"
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False) 
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String, nullable=False, default="customer") 
    full_name = db.Column(db.String, nullable=False)
    address = db.Column(db.String, nullable=False)
    phone_number = db.Column(db.String(13), nullable=False)
    pin = db.Column(db.Integer, nullable=False) 
    status = db.Column(db.String, nullable=False, default='active')
    
    # Relationships with Service Requests and Reviews
    service_requests = db.relationship("ServiceRequest", cascade="all,delete", backref='customer', lazy=True)
    reviews = db.relationship('Review', cascade="all,delete", backref='customer', lazy=True)

    def __repr__(self):
        return f'<Customer {self.full_name}>'

# Professional Table
class Professional(db.Model):
    __tablename__ = "professionals"
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)  
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String, nullable=False, default="professional")  
    full_name = db.Column(db.String, nullable=False)
    phone_number = db.Column(db.String(13), nullable=False)  
    service_name = db.Column(db.String,db.ForeignKey('services.name'), nullable=False)
    experience = db.Column(db.Integer, nullable=False)
    address = db.Column(db.String, nullable=False)
    resume_url=db.Column(db.String,nullable=True,default="None")
    pin = db.Column(db.Integer, nullable=False)  
    status = db.Column(db.String, nullable=False, default='pending')
    
    # Relationship with Service Requests
    service_requests = db.relationship('ServiceRequest', cascade="all,delete", backref='professional', lazy=True)

    def __repr__(self):
        return f'<Professional {self.full_name}>'

# Service Table
class Service(db.Model):
    __tablename__ = "services"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    price = db.Column(db.Integer, nullable=False)
    time_required = db.Column(db.Integer, nullable=False)
    description = db.Column(db.String, nullable=False)
    
    def __repr__(self):
        return f'<Service {self.name}>'

# ServiceRequest Table
class ServiceRequest(db.Model):
    __tablename__ = 'service_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey('professionals.id'), nullable=False)
    professional_name=db.Column(db.Text, nullable=False)
    customer_name=db.Column(db.Text, nullable=False)
    customer_phno=db.Column(db.String, nullable=False)
    professional_phno=db.Column(db.String, nullable=False)
    service_name=db.Column(db.Text, nullable=False)
    date_of_request = db.Column(db.DateTime) 
    service_status = db.Column(db.String(50), default='requested') 
    remarks = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f'<ServiceRequest {self.id}>'

# Review Table
class Review(db.Model):
    __tablename__ = 'reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    service_request_id = db.Column(db.Integer, db.ForeignKey('service_requests.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey('professionals.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # Rating expected between 1 and 5
    comment = db.Column(db.String(500), nullable=True)

    def __repr__(self):
        return f'<Review {self.id}>'
